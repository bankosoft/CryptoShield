﻿Imports System.Security.Cryptography
Imports System.Text
Public Class Form1
    Dim ip1 As String
    Dim ip2 As String
    Dim ip3 As String
    Dim ip4 As String




    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles TextBox1.TextChanged
        Dim inputText As String = TextBox1.Text

        ' MD5 hash számítása
        Dim md5Hash As MD5 = MD5.Create()
        Dim md5Bytes As Byte() = md5Hash.ComputeHash(Encoding.UTF8.GetBytes(inputText))
        Dim md5Builder As New StringBuilder()

        For i As Integer = 0 To md5Bytes.Length - 1
            md5Builder.Append(md5Bytes(i).ToString("x2"))
        Next

        TextBox2.Text = md5Builder.ToString()

        ' SHA256 hash számítása
        Dim sha256Hash As SHA256 = SHA256.Create()
        Dim sha256Bytes As Byte() = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(inputText))
        Dim sha256Builder As New StringBuilder()

        For i As Integer = 0 To sha256Bytes.Length - 1
            sha256Builder.Append(sha256Bytes(i).ToString("x2"))
        Next

        TextBox3.Text = sha256Builder.ToString()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Timer1.Enabled = True
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick

        ip1 = ip1 + 1

        TextBox1.Text = ip1

        If TextBox4.Text = TextBox2.Text Then
            Timer1.Enabled = False
        End If


    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        ip1 = 1
        ip2 = 1
        ip3 = 1
        ip4 = 1
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ip1 = 0
        TextBox1.Text = ""
    End Sub

    Private Sub TextBox6_TextChanged(sender As Object, e As EventArgs) Handles TextBox6.TextChanged
        TextBox1.Text = "InpoutToken;Username;" + TextBox5.Text + ";Password;" + TextBox6.Text + ";Login"
        RichTextBox1.Text = "https://vi.bankosoft.hu/authme/login/" + TextBox5.Text + "/" + TextBox3.Text + ".cry"
    End Sub

    Private Sub TextBox5_TextChanged(sender As Object, e As EventArgs) Handles TextBox5.TextChanged
        TextBox1.Text = "InpoutToken;Username;" + TextBox5.Text + ";Password;" + TextBox6.Text + ";Login"
        RichTextBox1.Text = "https://vi.bankosoft.hu/authme/login/" + TextBox5.Text + "/" + TextBox3.Text + ".cry"
    End Sub
End Class
